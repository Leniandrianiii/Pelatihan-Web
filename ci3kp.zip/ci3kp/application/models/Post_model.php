<?php
class Post_model extends CI_model
{
    public function tambahpostproduk($new_image)
    {
        $data = array(
            'nama' => $this->input->post('nama'),
            'ket' => $this->input->post('ket'),
            'image' => $new_image,
        );
        $this->db->insert('produk', $data);
    }
    public function getAllPost()
    {
        return $this->db->select("id,nama,ket")->get('produk')->result_array();
    }
    public function getPosts($limit, $start, $keyword = null)
    {
        return $this->db
            ->select("id,nama,ket")
            ->like('nama', $keyword)
            ->get('produk', $limit, $start)
            ->result_array();
    }
    public function getProduk($limit, $start, $keyword = null)
    {
        return $this->db
            ->select("id,nama,ket,image")
            ->order_by('id', 'DESC')
            ->like('nama', $keyword)
            ->get('produk', $limit, $start)
            ->result_array();
    }

    public function countPosts($keyword = null)
    {
        return $this->db->like('nama', $keyword)
            ->from('produk')
            ->count_all_results();
    }

    public function countProduk($keyword = null)
    {
        return $this->db->like('nama', $keyword)
            ->from('produk')
            ->count_all_results();
    }

    public function countAllPost()
    {
        return $this->db->get('produk')->num_rows();
    }

    public function getPostById($id)
    {

        return $this->db->select("id,nama,ket,image")->where('id', $id)->get('produk')->result_array();
    }

    public function updatePost($id)
    {
        $data = array(
            'nama' => $this->input->post('nama'),
            'ket' => $this->input->post('ket')
        );

        $this->db->where('id', $id)->update('produk', $data);
    }

    public function hapuspost($id)
    {
        $this->db->where('id', $id)->delete('produk');
    }
}
