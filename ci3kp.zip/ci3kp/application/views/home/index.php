<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>
        <?= $judul; ?>
    </title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="<?= base_url('bs home/'); ?>assets/img/favicon.ico" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
    <!-- Third party plugin CSS-->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?= base_url('bs home/'); ?>css/styles.css" rel="stylesheet" />
</head>

<body id="page-top">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
        <div class="container">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">Jafra Skincare</a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto my-2 my-lg-0">
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#about">About</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#services">Catalog</a></li>
                    <ul class="navbar-nav ml-auto my-2 my-lg-0">
                        <li class="nav-item active"><a class="nav-link" href="<?= base_url(); ?>post">Berkunjung</a></li>
                    </ul>
                    <li class="nav-item active"><a class="nav-link js-scroll-trigger" href="<?= base_url('auth'); ?>">Login</a></li>

                </ul>
            </div>
        </div>
    </nav>
    <!-- Masthead-->
    <header class="masthead">
        <div class="container h-100">
            <div class="row h-100 align-items-center justify-content-center text-center">
                <div class="col-lg-10 align-self-end">
                    <h1 class="text-uppercase text-white font-weight-bold">JAFRA COSMETICS</h1>
                    <hr class="divider my-4" />
                </div>
                <div class="col-lg-8 align-self-baseline">
                    <p class="text-white-75 font-weight-light mb-5">Rawat dan manjakan kulit sehatmu dengan rangkaian produk jafra*</p>
                    <!-- <a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">Find Out More</a> -->
                </div>
            </div>
        </div>
    </header>
    <!-- About-->
    <section class="page-section bg-primary" id="about">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h2 class="text-white mt-0">JAFRA</h2>
                    <hr class="divider light my-4" />
                    <p class="text-white-50 mb-4">JAFRA berdiri tahun 1956 di Malibu, California. Nama JAFRA sendiri merupakan gabungan dari nama kedua pendirinya, Jane dan Frank Day.
                        Produk JAFRA Cosmetics meliputi skincare, toiletries, fragrance dan makeup, dengan lebih dari 150 jenis produk.
                        Pabrik JAFRA terdapat di Meksiko dan sudah mendapat sertifikat Good Manufacture Practice (GMP), yang menjamin keamanan produk JAFRA. Brand kosmetik yang berada di bawah naungan Vorwerk Group) tersebut kini hadir di Indonesia dengan sistem penjualan berupa distribusi direct selling atau multi lever marketing (MLM).</p>
                    <a class="btn btn-light btn-xl js-scroll-trigger" href="#services">Get Started!</a>
                </div>
            </div>
        </div>
    </section>
    <!-- Services-->
    <section class="page-section" id="services">
        <div class="container">
            <div class="text-center">
                <h2 class="section-heading text-uppercase">Catalog</h2>
                <!-- <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3> -->
            </div>
            <!-- <?= $this->pagination->create_links(); ?>
            <div class="row text-center">
                <?php if (isset($post)) : ?>
                    <?php foreach ($post as $post) : ?>
                        <div class="col-md-4 mb-3 my-3">
                            <h3 class="text-truncate"><?= $post['judul']; ?></h3>
                            <p class="" style="-webkit-line-clamp:3; overflow:hidden; text-overflow:ellipsis; display: -webkit-box; -webkit-box-orient:vertical;"><?= $post['isi']; ?>
                            </p>
                            <a role="button" href="" class="btn btn-primary">Lihat &raquo;</a>
                            <hr>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?> -->


        </div>
        <!-- </div> -->
    </section>

    <!-- Portfolio-->
    <div id="portfolio">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="<?= base_url('bs home/'); ?>assets/img/portfolio/fullsize/royalb.png">
                        <img class="img-fluid" src="<?= base_url('bs home/'); ?>assets/img/portfolio/thumbnails/royalb.png" alt="" />
                        <div class="portfolio-box-caption">
                            <div class="project-category text-white-50">Category</div>
                            <div class="project-name">ROYAL BOOST</div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="<?= base_url('bs home/'); ?>assets/img/portfolio/fullsize/scrub.jpg">
                        <img class="img-fluid" src="<?= base_url('bs home/'); ?>assets/img/portfolio/thumbnails/scrub.jpg" alt="" />
                        <div class="portfolio-box-caption">
                            <div class="project-category text-white-50">Category</div>
                            <div class="project-name">SCRUB</div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="<?= base_url('bs home/'); ?>assets/img/portfolio/fullsize/royalbp.jpg">
                        <img class="img-fluid" src="<?= base_url('bs home/'); ?>assets/img/portfolio/thumbnails/royalbp.jpg" alt="" />
                        <div class="portfolio-box-caption">
                            <div class="project-category text-white-50">Category</div>
                            <div class="project-name">ROYAL BOOST</div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="<?= base_url('bs home/'); ?>assets/img/portfolio/fullsize/mudmask.jpg">
                        <img class="img-fluid" src="<?= base_url('bs home/'); ?>assets/img/portfolio/thumbnails/mudmask.jpg" alt="" />
                        <div class="portfolio-box-caption">
                            <div class="project-category text-white-50">Category</div>
                            <div class="project-name">MUD MASK</div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="<?= base_url('bs home/'); ?>assets/img/portfolio/fullsize/serum.jpg">
                        <img class="img-fluid" src="<?= base_url('bs home/'); ?>assets/img/portfolio/thumbnails/serum.jpg" alt="" />
                        <div class="portfolio-box-caption">
                            <div class="project-category text-white-50">Category</div>
                            <div class="project-name">SERUM</div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a class="portfolio-box" href="<?= base_url('bs home/'); ?>assets/img/portfolio/fullsize/rlunaw.jpg">
                        <img class="img-fluid" src="<?= base_url('bs home/'); ?>assets/img/portfolio/thumbnails/rlunaw.jpg" alt="" />
                        <div class="portfolio-box-caption p-3">
                            <div class="project-category text-white-50">Category</div>
                            <div class="project-name">ROYAL BOOST LUNA WHITE</div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>


</html>