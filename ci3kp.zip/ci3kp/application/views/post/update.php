<div class="container">

    <div class="row mt-5">
        <div class="col-md-4"></div>
        <div class="col-md-4 ">
            <?php foreach ($produk as $posts) : ?>
                <div class="card">
                    <div class="card-header text-center" style="background-color: darkgreen; color:darkorange">
                        <h5>U P D A T E P R O D U K</h5>
                    </div>
                    <div class="card-body" style="background-color: aquamarine; color:darkred">
                        <form action="<?= base_url('post/prosesupdate/') ?><?= $posts['id'] ?>" method="POST">
                            <div class="form-group">
                                <label for="nama">Nama Produk</label>
                                <input type="text" class="form-control" name="nama" id="nama" laceholder="Masukkan nama produk" value="<?= $posts['nama'] ?>">
                                <?= form_error('nama', '<small class="text-danger">', '</small>') ?>
                            </div>

                            <div class="form-group">
                                <label for="ket">Deskripsi</label>
                                <textarea class="form-control" name="ket" id="ket" placeholder="Masukkan Deskripsi Produk"><?= $posts['ket'] ?></textarea>
                                <?= form_error('ket', '<small class="text-danger">', '</small>') ?>
                            </div>
                            <center> <button type="submit" class="btn btn-primary">Update</button>
                                <a href="<?= base_url() ?>post" class="btn btn-secondary">Batal</a>
                            </center>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>