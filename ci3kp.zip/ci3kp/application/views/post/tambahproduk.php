<div class="container">
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Tambah Post
                </div>
                <div class="card-body">

                    <!-- <form action="<?= base_url() ?>post/prosesTambahproduk" method="POST" enctype="multipart/form-data"> -->
                    <?= form_open_multipart('post/prosesTambahproduk'); ?>
                    <div class="form-group">
                        <label for="nama" class="">nama</label>
                        <input type="text" class="form-control" name="nama" id="nama" placeholder="masukan nama produk" required>
                    </div>

                    <div class="form-group">
                        <label for="ket" class="">ket</label>
                        <textarea class="form-control" name="ket" id="ket" placeholder="Masukan keterangan" required></textarea>
                    </div>
                    <div class="form-group row">
                        <label for="image" class="">Picture</label>
                        <div class="col-sm-10">
                            <div class="row">

                                <div class="col-sm-9">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="image" name="image">
                                        <label class="custom-file-label" for="image">Choose file</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>