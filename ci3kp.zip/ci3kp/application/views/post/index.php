<div class="container-fluid">
    <div class="container">
        <div class="row">

            <div class="p-3">
                <?php if ($this->session->userdata('email')) { ?>
                    <a href="<?= base_url() ?>post/tambahproduk" class="btn btn-primary align-self-center">Add Product</a>
                <?php } ?>

            </div>
            <div class="bg-dark">
                <?= $this->pagination->create_links(); ?>
            </div>
            <div class="col mx-auto p-3">
                <h1>JAFRA COSMETICS</h1>
            </div>
            <!-- Page Heading -->

        </div>

        <div class="row">

            <!-- <?= $this->session->flashdata('massage'); ?> -->
        </div>
        <div class="row mb-3">
            <?php if (isset($produk)) :  ?>
                <?php foreach ($produk as $produk) : ?>
                    <div class="col-6 mx-auto mb-3">
                        <div class="card">
                            <div class="row no-gutters">
                                <div class="col">
                                    <img src="<?= base_url('assets/img/produk/') . $produk['image'] ?>" class="img-thumbnail" width="200px">
                                </div>
                                <div class="col">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <?= $produk['nama']; ?>
                                        </h5>

                                        <p style="-webkit-line-clamp:3; overflow:hidden;
            text-overflow:ellipsis; display: -webkit-box; 
            -webkit-box-orient:vertical;">

                                            <?= $produk['ket']; ?>
                                        </p>
                                        <a role="button" href=" <?= base_url() ?>post/lihat/<?= $produk['id'] ?>"> <button type="button" class="mx-auto btn btn-info">Lihat</button></a>
                                    </div>

                                    <?php if ($this->session->userdata('email')) { ?>
                                        <a role="button" href="<?= base_url('post/update/'); ?><?= $produk['id'] ?>" class="btn btn-success">Update</a>
                                        <a role="button" href="<?= base_url() ?>post/hapus/<?= $produk['id'] ?>" class="btn btn-danger" onclick="return confirm('Hapus Post ?')">Delete</a>
                                    <?php } ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="bg-dark">
            <?= $this->pagination->create_links(); ?>
        </div>
    </div>