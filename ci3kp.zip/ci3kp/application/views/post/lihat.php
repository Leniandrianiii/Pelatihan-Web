<div class="container">
    <div class="row">
        <div class="col d-flex justify-content-between my-5">
            <?php foreach ($produk as $posts) : ?>
                <div class="card">
                    <div class="card-header"><img src="<?= base_url('assets/img/produk/') . $posts['image'] ?>" class="img-thumbnail">
                    </div>
                    <div class="card-body">
                        <h2> <?= $posts['nama']; ?></h2>
                        <p><?= $posts['ket']; ?></p>
                    </div>
                    <div class="card-footer">
                        <a role="button" class="btn btn-secondary" href="<?= base_url('post'); ?>">kembali</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>