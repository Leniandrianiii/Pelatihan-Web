<?php
class Post extends CI_Controller
{
    public function __construct()
    {
        Parent::__construct();
        $this->load->model('Post_model');
        $this->load->library('form_validation');
    }

    public function tambahproduk()
    {
        $data['judul'] = "Tambah Post";



        $this->load->view('templates/header', $data);
        $this->load->view('post/tambahproduk', $data);
        $this->load->view('templates/footer');
    }

    public function prosesTambahproduk()
    {
        // $this->Post_model->tambahpostproduk();
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('ket', 'Keterangan', 'required|trim');
        $nama = $this->input->post('nama');
        $ket = $this->input->post('ket');
        $img = $this->input->post('image');
        $upload_image = $_FILES['image']['name'];
        if ($upload_image) {
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '2048';
            $config['upload_path'] = './assets/img/produk/';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('image')) {
                $new_image = $this->upload->data('file_name');
                // $this->db->set('image', $new_image);
            } else {
                echo $this->upload->display_errors();
            }
        }
        // $this->Post_model->tambahpostproduk($new_image);
        $data = array(
            'nama' => $this->input->post('nama'),
            'ket' => $this->input->post('ket'),
            'image' => $new_image,
        );
        $this->db->insert('produk', $data);
        echo "sukses menambahkan";
        redirect('post');
    }
    public function index()
    {
        $email = $this->session->userdata('email');
        $data['judul'] = 'Halaman Home';
        $data['user'] = $this->db->get_where('user', ['email' => $email])->row_array();

        $this->load->library('pagination');

        $config['base_url'] = 'http://localhost/ci3kp/post';

        if ($this->session->userdata('keyword') == false) {

            $this->session->set_userdata('keyword', '');
        }

        if (isset($_POST['submit'])) {
            $data['keyword'] = $this->input->post('keyword');
            $this->session->set_userdata('keyword', $data['keyword']);
        } else {
            $data['keyword'] = $_SESSION['keyword'];
        }
        $config['total_rows'] = $this->Post_model->countProduk($data['keyword']);

        $config['per_page'] = 9;

        $this->pagination->initialize($config);

        $data['start'] = $this->uri->segment(3);

        $data['produk'] = $this->Post_model->getProduk($config['per_page'], $data['start'], $data['keyword']);

        $this->load->view('templates/header', $data);
        $this->load->view('post/index', $data);
        $this->load->view('templates/footer');
    }

    public function update($id)
    {
        $data['nama'] = "update Post";
        $data['produk'] = $this->Post_model->getPostById($id);
        $this->load->view('templates/header', $data);
        $this->load->view('post/update', $data);
        $this->load->view('templates/footer');
    }

    public function prosesUpdate($id)
    {
        $this->Post_model->updatePost($id);

        redirect(base_url() . "post");
    }
    public function hapus($id)
    {
        $this->Post_model->hapuspost($id);
        redirect(base_url() . "post");
    }
    public function lihat($id)
    {
        $data['nama'] = 'lihat produk';
        $data['produk'] = $this->Post_model->getPostById($id);
        $this->load->view('templates/header', $data);
        $this->load->view('post/lihat', $data);
        $this->load->view('templates/footer');
    }
}
