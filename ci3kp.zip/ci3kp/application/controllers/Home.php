 <?php
   class Home extends CI_Controller
   {
      public function __construct()
      {
         Parent::__construct();
         $this->load->model('Post_model');
      }
      public function index()
      {
         $email = $this->session->userdata('email');
         $data['judul'] = 'Halaman Home';
         $data['user'] = $this->db->get_where('user', ['email' => $email])->row_array();

         $email = $this->session->userdata('email');
         $data['judul'] = 'Halaman Home';
         $data['user'] = $this->db->get_where('user', ['email' => $email])->row_array();

         $this->load->library('pagination');

         $config['base_url'] = 'http://localhost/ci3kp/home/index';

         if ($this->session->userdata('keyword') == false) {

            $this->session->set_userdata('keyword', '');
         }

         if (isset($_POST['submit'])) {
            $data['keyword'] = $this->input->post('keyword');
            $this->session->set_userdata('keyword', $data['keyword']);
         } else {
            $data['keyword'] = $_SESSION['keyword'];
         }
         $config['total_rows'] = $this->Post_model->countPosts($data['keyword']);

         $config['per_page'] = 9;

         $this->pagination->initialize($config);

         $data['start'] = $this->uri->segment(3);

         $data['post'] = $this->Post_model->getPosts($config['per_page'], $data['start'], $data['keyword']);


         //$this->load->view('templates/header', $data);
         $this->load->view('home/index', $data);
         $this->load->view('templates/footer');
      }
   }
