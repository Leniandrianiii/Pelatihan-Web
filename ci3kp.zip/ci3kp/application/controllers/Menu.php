<?php
defined('BASEPATH') or exit('No direct script access allowed');

class  Menu extends CI_Controller
{
    public function  index()
    {
        $data['judul'] = 'Skincare';
        $data['users'] = $this->db->get_where('users', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('templates/headerlog', $data);
        $this->load->view('templates/sidebarlog', $data);
        $this->load->view('templates/topbarlog', $data);
        $this->load->view('menu/index', $data);
        $this->load->view('templates/footerlog');
    }
}
